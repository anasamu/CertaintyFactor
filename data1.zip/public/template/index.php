<!DOCTYPE html>
<!--[if IE 8]> <html lang="en" class="ie8"> <![endif]-->
<!--[if !IE]><!-->
<html lang="en">
<!--<![endif]-->

<head>
    <meta charset="utf-8" />
    <title><?php echo $this->config->item('judul_aplikasi');?></title>
    <meta content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" name="viewport" />
    <meta content="" name="description" />
    <meta content="" name="author" />
    
    <!-- ================== BEGIN BASE CSS STYLE ================== -->
    <link href="<?php echo base_url('assets/plugins/jquery-ui/themes/base/minified/jquery-ui.min.css');?>" rel="stylesheet" />
    <link href="<?php echo base_url('assets/plugins/bootstrap/css/bootstrap.min.css');?>" rel="stylesheet" />
    <link href="<?php echo base_url('assets/plugins/font-awesome/css/font-awesome.min.css');?>" rel="stylesheet" />
    <link href="<?php echo base_url('assets/css/animate.min.css');?>" rel="stylesheet" />
    <link href="<?php echo base_url('assets/css/style.min.css');?>" rel="stylesheet" />
    <link href="<?php echo base_url('assets/css/style-responsive.min.css');?>" rel="stylesheet" />
    <link href="<?php echo base_url('assets/css/theme/default.css');?>" rel="stylesheet" id="theme" />
    <!-- ================== END BASE CSS STYLE ================== -->
    <link href="<?php echo base_url('assets/plugins/DataTables/media/css/dataTables.bootstrap.min.css');?>" rel="stylesheet" />
    <link href="<?php echo base_url('assets/plugins/DataTables/extensions/FixedHeader/css/fixedHeader.bootstrap.min.css');?>" rel="stylesheet" />
    <link href="<?php echo base_url('assets/plugins/DataTables/extensions/Responsive/css/responsive.bootstrap.min.css');?>" rel="stylesheet" />
    <!-- ================== BEGIN BASE JS ================== -->
    <script src="<?php echo base_url('assets/plugins/pace/pace.min.js');?>"></script>
    <!-- ================== END BASE JS ================== -->
</head>
<body>
    <!-- begin #page-loader -->
    
    <!-- end #page-loader -->
    
    <!-- begin #page-container -->
    <div id="page-container" class="fade page-container page-without-sidebar page-header-fixed page-with-top-menu in gradient-enabled">
        <!-- begin #header -->
        <div id="header" class="header navbar navbar-default navbar-fixed-top">
            <!-- begin container-fluid -->
            <div class="container-fluid">
                <!-- begin mobile sidebar expand / collapse button -->
                <div class="nav navbar-nav">
                    <h3 class="navbar-text"><?php echo $this->config->item('judul_aplikasi');?></h3>
                </div>
                <!-- end mobile sidebar expand / collapse button -->
                
                <?php if ($this->session->userdata('logged_in') == TRUE):?>
                <!-- begin header navigation right -->
                <ul class="nav navbar-nav navbar-right">
                    <li class="dropdown navbar-user">
                        <a href="javascript:;" class="dropdown-toggle" data-toggle="dropdown">
                            <img src="<?php echo base_url('assets/img/user.jpg');?>" alt="" /> 
                            <span class="hidden-xs"><?php echo $this->session->userdata('nama_user');?></span> <b class="caret"></b>
                        </a>
                        <ul class="dropdown-menu animated fadeInLeft">
                            <li class="arrow"></li>
                            <li><a href="<?php echo base_url('index.php/profil');?>">Profil</a></li>
                            <li class="divider"></li>
                            <li><a href="<?php echo base_url('index.php/keluar');?>">Log Out</a></li>
                        </ul>
                    </li>
                </ul>
                <!-- end header navigation right -->
                <?php endif;?>
            </div>
            <!-- end container-fluid -->
        </div>
        <!-- end #header -->
        
        <!-- begin #top-menu -->
        <div id="top-menu" class="top-menu">
            <!-- begin top-menu nav -->
        <ul class="nav">
        <?php if ($this->session->userdata('logged_in') == FALSE):?>
        <li><a href="<?php echo base_url('index.php/beranda');?>"><i class="fa fa-home"></i> <span>Beranda</span></a></li>
        <li><a href="<?php echo base_url('index.php/diagnosa');?>"><i class="fa fa-flask"></i> <span>Diagnosa</span></a></li>
        <li><a href="<?php echo base_url('index.php/profil');?>"><i class="fa fa-user"></i> <span>Profile</span></a></li>
        <li><a href="<?php echo base_url('index.php/bantuan');?>"><i class="fa fa-info"></i> <span>Bantuan</span></a></li>
        <li><a href="#login" data-toggle="modal"><i class="fa fa-key"></i> <span>Login</span></a></li>
        <?php else:?>
        <li><a href="<?php echo base_url('index.php/beranda');?>"><i class="fa fa-home"></i> <span>Beranda</span></a></li>
        <li><a href="<?php echo base_url('index.php/diagnosa');?>"><i class="fa fa-flask"></i> <span>Diagnosa</span></a></li>
        <li><a href="<?php echo base_url('index.php/penyakit');?>"><i class="fa fa-flask"></i> <span>Penyakit</span></a></li>
        <li><a href="<?php echo base_url('index.php/gejala');?>"><i class="fa fa-flask"></i> <span>Gejala</span></a></li>
        <li><a href="<?php echo base_url('index.php/pengetahuan');?>"><i class="fa fa-flask"></i> <span>Pengetahuan</span></a></li>
        <li><a href="<?php echo base_url('index.php/nilai');?>"><i class="fa fa-flask"></i> <span>Nilai</span></a></li>
        <li><a href="<?php echo base_url('index.php/profil');?>"><i class="fa fa-user"></i> <span>Profile</span></a></li>
        <li><a href="<?php echo base_url('index.php/bantuan');?>"><i class="fa fa-info"></i> <span>Bantuan</span></a></li>
        <?php endif;?>
        </ul>
            <!-- end top-menu nav -->
        </div>
        <!-- end #top-menu -->
        
        <!-- begin #content -->
        <div id="content" class="content">
            <!-- begin page-header -->
            <h1 class="page-header"><?php echo $this->config->item('judul_aplikasi');?><br/>
                <small><?php echo $this->config->item('deskripsi_aplikasi');?></small>
            </h1>
            <!-- end page-header -->
            
            <div class="row">
                <div class="col-md-12">
                    <?php echo $this->session->flashdata('pesan');?>
                    <?php echo $content;?>
                </div>
            </div>
            <?php if($this->session->userdata('logged_in') == FALSE):?> 
            <div class="modal fade in" id="login">
                <div class="modal-dialog">
                    <form class="form" method="POST" action="<?php echo base_url('index.php/masuk');?>">
                    <div class="modal-content">
                        <div class="modal-header">
                            <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                            <h4 class="modal-title">Login User</h4>
                        </div>
                        <div class="modal-body">
                            <div class="form-group">
                              <label for="usr">Username:</label>
                              <input name="usr" type="text" class="form-control" id="usr">
                            </div>
                            <div class="form-group">
                                <label for="pwd">Password:</label>
                                <input name="pwd" type="password" class="form-control" id="pwd">
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="reset" class="btn btn-primary">Reset</button>
                            <button type="submit" class="btn btn-success">Login</button>
                        </div>
                    </div>
                    </form>
                </div>
            </div>
            <?php endif;?>
            <hr/>
            <footer>
                © <?php echo date('Y').' '. $this->config->item('tempat_penelitian');?> - <?php echo $this->config->item('nama_mahasiswa');?> All Rights Reserved
            </footer>
        </div>
        <!-- end #content -->

                
        <!-- begin scroll to top btn -->
        <a href="javascript:;" class="btn btn-icon btn-circle btn-success btn-scroll-to-top fade" data-click="scroll-top"><i class="fa fa-angle-up"></i></a>
        <!-- end scroll to top btn -->
    </div>
    <!-- end page container -->
    
    <!-- ================== BEGIN BASE JS ================== -->
    <script src="<?php echo base_url('assets/plugins/jquery/jquery-1.9.1.min.js');?>"></script>
    <script src="<?php echo base_url('assets/plugins/jquery/jquery-migrate-1.1.0.min.js');?>"></script>
    <script src="<?php echo base_url('assets/plugins/jquery-ui/ui/minified/jquery-ui.min.js');?>"></script>
    <script src="<?php echo base_url('assets/plugins/bootstrap/js/bootstrap.min.js');?>"></script>
    <!--[if lt IE 9]>
        <script src="assets/crossbrowserjs/html5shiv.js"></script>
        <script src="assets/crossbrowserjs/respond.min.js"></script>
        <script src="assets/crossbrowserjs/excanvas.min.js"></script>
    <![endif]-->
    <script src="<?php echo base_url('assets/plugins/DataTables/media/js/jquery.dataTables.js');?>"></script>
    <script src="<?php echo base_url('assets/plugins/DataTables/media/js/dataTables.bootstrap.min.js');?>"></script>
    <script src="<?php echo base_url('assets/plugins/DataTables/extensions/FixedHeader/js/dataTables.fixedHeader.min.js');?>"></script>
    <script src="<?php echo base_url('assets/plugins/DataTables/extensions/Responsive/js/dataTables.responsive.min.js');?>"></script>
    <script src="<?php echo base_url('assets/js/table-manage-fixed-header.demo.min.js');?>"></script>
    <script src="<?php echo base_url('assets/plugins/slimscroll/jquery.slimscroll.min.js');?>"></script>
    <script src="<?php echo base_url('assets/plugins/jquery-cookie/jquery.cookie.js');?>"></script>
    <!-- ================== END BASE JS ================== -->
    
    <!-- ================== BEGIN PAGE LEVEL JS ================== -->
    <script src="<?php echo base_url('assets/js/apps.min.js');?>"></script>
    <!-- ================== END PAGE LEVEL JS ================== -->
    
    <script>
        $(document).ready(function() {
            App.init();
            TableManageFixedHeader.init();
        });
    </script>

</body>

</html>
