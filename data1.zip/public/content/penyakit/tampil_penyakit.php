<h3>Penyakit : <?php echo $penyakit->nm_penyakit;?></h3>
<hr/>
<div class="row">
	<div class="col col-md-12">
	<table class="table table-bordered table-hover table-responsive table-striped">
		<tr>
			<th>TGL INPUT</th>
			<td><?php echo $this->apps->date($penyakit->tgl_input);?></td>
		</tr>
		<tr>
			<th>ID PENYAKIT</th>
			<td><?php echo $penyakit->kd_penyakit;?></td>	
		</tr>	
		<tr>
			<th>NAMA PENYAKIT</th>
			<td><?php echo $penyakit->nm_penyakit;?></td>
		</tr>
		<tr>
			<th>Definisi Penyakit</th>
			<td><?php echo $penyakit->definisi;?></td>
		</tr>
		<tr>
			<th>Penyebab Penyakit</th>
			<td><?php echo $penyakit->penyebab;?></td>
		</tr>
		<tr>
			<th>Solusi Penyakit</th>
			<td><?php echo $penyakit->solusi;?></td>
		</tr>
		<tr>
			<th>Gejala</th>
			<td>
				<?php
					$query = $this->db->where('kd_penyakit',$penyakit->kd_penyakit)
									  ->get('tb_relasi');
					if ($query->num_rows() > 0) 
					{
						echo "<p>Daftar Gejala yang terkait dengan Penyakit ini :</p>";
						foreach ($query->result() as $gejala) 
						{
						 	$query = $this->db->where('kd_gejala', $gejala->kd_gejala)
												->get('tb_gejala');
							if ($query->num_rows() > 0) 
							{
								foreach ($query->result() as $items) 
								{
									echo "- ".$items->nm_gejala."<br/>";
								}
							}
						}
					}
					else
					{
						echo "belum ada data gejala yang terhubung dengan penyakit ini.";
					}

				?>
			</td>
		</tr>
	</table>
	<a href="<?php echo base_url('index.php/penyakit');?>" class="btn btn-success">Kembali</a>
	</div>
</div>