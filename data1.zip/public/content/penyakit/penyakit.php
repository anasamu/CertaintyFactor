<?php 
$query = $this->db->get('tb_penyakit');
?>
<div class="row">

	<h3>Daftar Penyakit</h3>
	<hr/>
	<table id="data-table" class="table table-bordered table-hover table-responsive table-striped">
	<thead>
		<tr>
			<th>ID Penyakit</th>
		    <th>Jenis Penyakit</th>
		    <th>Definisi</th>
			<th>Aksi</th>
		</tr>
	</thead>
	<tbody>
	<?php foreach ($query->result() as $items):?>
		<tr>
			<td><?php echo $items->kd_penyakit;?></td>
			<td><?php echo $items->nm_penyakit;?></td>
			<td><?php echo nl2br($items->definisi);?></td>
			<td>
				<div class="btn-group btn-group-sm">
					<a aria-expanded="false" href="#" data-toggle="dropdown" class="btn btn-danger dropdown-toggle">Action <span class="caret"></span></a>
					<ul class="dropdown-menu">
						<li>
							<a href="<?php echo base_url('index.php/penyakit/tampil/'.$items->kd_penyakit);?>">Tampil</a>
						</li>
						<li>
							<a href="<?php echo base_url('index.php/penyakit/edit/'.$items->kd_penyakit);?>">Edit</a>
						</li>
						<li class="divider"></li>
						<li>
							<a data-toggle="modal" href="#hapus-<?php echo $items->kd_penyakit;?>">Delete</a>
						</li>
					</ul>
				</div>
			</td>
		</tr>
	<?php endforeach;?>
	</tbody>
	<tfoot>
		<tr>
			<td colspan="4"><a href="<?php echo base_url('index.php/penyakit/tambah');?>" class="btn btn-success">Tambah Data</a></td>
		</tr>
	</tfoot>
	</table>
</div>

<?php foreach ($query->result() as $items) :?>

<div class="modal fade" id="hapus-<?php echo $items->kd_penyakit;?>">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
				<h4 class="modal-title">Hapus Penyakit</h4>
			</div>
			<div class="modal-body">
				<p>Apakah anda yakin ingin menghapus ID Penyakit : <?php echo $items->kd_penyakit;?> ?<br/>
				Menghapus Data Penyakit akan mempengaruhi data pengetahuan dan data nilai yang terkait dengan penyakit ini.</p>
			</div>
			<div class="modal-footer">
				<a href="#" class="btn btn-sm btn-white" data-dismiss="modal">Close</a>
				<a href="<?php echo base_url('index.php/penyakit/hapus/'.$items->kd_penyakit);?>" class="btn btn-sm btn-danger">Hapus</a>
			</div>
		</div>
	</div>
</div>
<?php endforeach;?>