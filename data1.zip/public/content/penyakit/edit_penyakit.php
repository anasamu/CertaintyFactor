<div class="row">
    <div class="col-md-8 ui-sortable">
        <div style="" class="panel panel-inverse">
            <div class="panel-heading">
                <h4 class="panel-title">Edit Data Penyakit</h4>
            </div>
            <div class="panel-body">
				<form class="form" method="POST" action="<?php echo base_url('index.php/penyakit/edit');?>">
				    <div class="form-group">
				      <label for="id">ID Penyakit:</label>
				      <input value="<?php echo $penyakit->kd_penyakit;?>" name="id_penyakit" readonly="readonly" type="text" class="form-control" id="id">
				    </div>
				    <div class="form-group">
				        <label for="nama_penyakit">Nama Penyakit:</label>
				        <input value="<?php echo $penyakit->nm_penyakit;?>" name="nama_penyakit" type="text" class="form-control" id="nama_penyakit">
				    </div>
				    <div class="form-group">
				        <label for="definisi_penyakit">Definisi:</label>
				        <textarea name="definisi_penyakit" class="form-control" id="definisi_penyakit"><?php echo $penyakit->definisi;?></textarea>
				    </div>
				    <div class="form-group">
				        <label for="penyebab_penyakit">Penyebab:</label>
				        <textarea name="penyebab_penyakit" class="form-control" id="penyebab_penyakit"><?php echo $penyakit->penyebab;?></textarea>
				    </div>
				    <div class="form-group">
				        <label for="solusi_penyakit">Solusi:</label>
				        <textarea name="solusi_penyakit" class="form-control" id="solusi_penyakit"><?php echo $penyakit->solusi;?></textarea>
				    </div>
				    <div class="form-group">
				        <label for="simpan"></label>
				        <button type="submit" class="btn btn-success" id="simpan">Update Data Penyakit</button>
				    </div>
				</form>
            </div>
        </div>
    </div>
</div>