<div class="row">
    <div class="col-md-8 ui-sortable">
        <div style="" class="panel panel-inverse">
            <div class="panel-heading">
                <h4 class="panel-title">Tambah Data Penyakit</h4>
            </div>
            <div class="panel-body">
				<form class="form" method="POST" action="<?php echo base_url('index.php/penyakit/tambah');?>">
				    <div class="form-group">
				      <label for="id">ID Penyakit:</label>
				      <input name="id_penyakit" value="<?php echo $this->apps->id_table('P00','kd_penyakit','tb_penyakit');?>" type="text" class="form-control" id="id" readonly="readonly">
				    </div>
				    <div class="form-group">
				        <label for="nama_penyakit">Nama Penyakit:</label>
				        <input name="nama_penyakit" type="text" class="form-control" id="nama_penyakit">
				    </div>
				    <div class="form-group">
				        <label for="definisi_penyakit">Definisi:</label>
				        <textarea name="definisi_penyakit" class="form-control" rows="4" id="definisi_penyakit"></textarea>
				    </div>
				    <div class="form-group">
				        <label for="penyebab_penyakit">Penyebab:</label>
				        <textarea name="penyebab_penyakit" class="form-control" id="penyebab_penyakit" rows="4"></textarea>
				    </div>
				    <div class="form-group">
				        <label for="solusi_penyakit">Solusi:</label>
				        <textarea name="solusi_penyakit" class="form-control" id="solusi_penyakit" rows="4"></textarea>
				    </div>
				    <div class="form-group">
				        <label for="simpan"></label>
				        <button type="reset" class="btn btn-primary" id="simpan">Reset</button>
				        <button type="submit" class="btn btn-success" id="simpan">Simpan Data Penyakit</button>
				    </div>
				</form>
            </div>
        </div>
    </div>
</div>