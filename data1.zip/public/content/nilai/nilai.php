<div style="" class="panel panel-inverse" data-sortable-id="form-stuff-1">
    <div class="panel-heading">
        <h4 class="panel-title">Data Nilai</h4>
    </div>
	<div class="panel-body">
            <form action="<?php echo base_url('index.php/nilai');?>" method="GET" class="form-horizontal">
            <div class="form-group">
                <label class="col-md-4 control-label">Pilih Data Penyakit : </label>
                <div class="col-md-3">
                    <select name="id" class="form-control">
                        <option value="0">Data Penyakit</option>
                        <?php
                        	$query = $this->db->get('tb_penyakit');

                        	foreach ($query->result() as $items) 
                        	{
                        		echo "<option value='".$items->kd_penyakit."'>".$items->nm_penyakit."</option>";
                        	}
                        ?>
                    </select>
                </div>
                <div>
                	<button type="submit" class="btn btn-success">Proses Penyakit</button>
                </div>
            </div>
            </form>
            <form action="<?php echo base_url('index.php/nilai/update');?>" method="POST">
            <hr/>
            <?php 
            	$id_penyakit	 = $this->input->get('id');
            	$query 			 = $this->db->where('kd_penyakit',$id_penyakit)
            								->get('tb_penyakit');
            	if ($query->num_rows() > 0) 
            	{
            	 	echo "<h3>Penyakit yang dipilih : ".$query->row()->nm_penyakit."</h3>";
            	 	echo "<input type='hidden' name='kd_penyakit' value='".$query->row()->kd_penyakit."'>";
            	}
            ?>
            <table class="table table-hover table-responsive table-bordered table-striped">
            	<thead>
            		<tr>
            			<th align="center">NO</th>
            			<th>NAMA GEJALA</th>
            			<th>Nilai MB</th>
            			<th>Nilai MD</th>
            		</tr>
            	</thead>
            	<tbody>
            		<?php 
            			$no =1;
            			$query = $this->db->where('kd_penyakit',$id_penyakit)->get('tb_relasi');
            		?>
            		<?php if ($query->num_rows() > 0):?>
	            		<?php foreach ($query->result() as $items):?>
	            		<tr>
	            			<td align="center"><?php echo $no++;?></td>
	            			<?php
	            				$gejala = $this->db->where('kd_gejala',$items->kd_gejala)->get("tb_gejala");
	            			?>
	            			<td><?php echo $gejala->row()->nm_gejala;?></td>
	            			<td>
	            				<input type="hidden" value="<?php echo $items->kd_gejala;?>" name="kd_gejala[]">
	            				<input value="<?php echo $items->mb;?>" type="text" name="nilai_mb[]" class="form-control">
	            			</td>
	            			<td>
	            				<input value="<?php echo $items->md;?>" type="text" name="nilai_md[]" class="form-control">
	            			</td>
	            		</tr>
		            	<?php endforeach;?>
		            <?php else:?>
		            	<tr>
		            		<?php if ($id_penyakit) 
		            		{
		            			echo '<td colspan="4">Data Kosong! Silahkan <a href="'.base_url("index.php/pengetahuan?id=".$id_penyakit.'&redirect=nilai').
                                '">klik disini</a> untuk menambahkan data pengetahuan.</td>';
		            		}
		            		else
		            		{
		            			echo '<td colspan="4">Data Penyakit belum di pilih.</td>';
		            		}?>
		            	</tr>
		            <?php endif;?>
            	</tbody>
            </table>
            <?php if ($id_penyakit):?>
            <button type="submit" class="btn btn-success pull-right">Simpan Data</button>
            </form>
            <?php endif;?>
    </div>
</div>
