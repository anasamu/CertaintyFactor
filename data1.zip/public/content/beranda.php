<?php
$materi       = array(array('title' => 'Penyakit Stroke',
                            'content' => 'Stroke adalah gangguan fungsi saraf yang disebabkan oleh gangguan aliran darah dalam otak yang dapat timbul secara mendadak dalam beberapa detik atau secara cepat dalam beberapa jam dengan gejala atau tanda-tanda sesuai dengan daerah yang terganggu. Menurut WHO: stroke adalah terjadinya gangguan fungsional otak fokal maupun global secara mendadak dan akut yang berlangsung lebih dari 24 jam akibat gangguan aliran darah otak. Menurut Neil F. Gordon: stroke adalah gangguan potensial yang fatal pada suplai darah bagian otak. Tidak ada satupun bagian tubuh manusia yang dapat bertahan bila terdapat gangguan suplai darah dalam waktu relative lama sebab darah sangat dibutuhkan dalam kehidupan terutama oksigen pengangkut bahan makanan yang dibutuhkan pada otak dan otak adalah pusat control system tubuh termasuk perintah dari semua gerakan fisik. Dengan kata lain stroke merupakan manifestasi keadaan pembuluh darah cerebral yang tidak sehat sehingga bisa disebut juga "cerebral arterial disease" atau "cerebrovascular disease". Cedera dapat disebabkan oleh sumbatan bekuan darah, penyempitan pembuluh darah, sumbatan dan penyempitan atau pecahnya pembuluh darah, semua ini menyebabkan kurangnya pasokan darah yang memadai (Irfan, 2010).'),
                    array('title' => 'Definisi Sistem Pakar',
                          'content' => 'Sistem pakar adalah suatu program komputer yang mengandung pengetahuan dari satu atau lebih pakar manusia mengenai suatu bidang spesifik. Jenis program ini pertama kali dikembangkan oleh periset kecerdasan buatan pada dasawarsa 1960-an dan 1970-an dan diterapkan secara komersial selama 1980-an.

                                Bentuk umum sistem pakar adalah suatu program yang dibuat berdasarkan suatu set aturan yang menganalisis informasi (biasanya diberikan oleh pengguna suatu sistem) mengenai suatu kelas masalah spesifik serta analisis matematis dari masalah tersebut. Tergantung dari desainnya, sistem pakar juga mampu merekomendasikan suatu rangkaian tindakan pengguna untuk dapat menerapkan koreksi. Sistem ini memanfaatkan kapabilitas penalaran untuk mencapai suatu simpulan.'),
                    array('title' => 'Metode Certainty Factor',
                          'content' => 'Faktor kepastian (certainty factor) diperkenalkan oleh Shortliffe Buchanan dalam pembuatan MYCIN pada tahun 1975 untuk mengakomadasi ketidakpastian pemikiran (inexact reasoning) seorang pakar. Teori ini berkembang bersamaan dengan pembuatan sistem pakar MYCIN. Team pengembang MYCIN mencatat bahwa dokter sering kali menganalisa informasi yang ada dengan ungkapan seperti misalnya: mungkin, kemungkinan besar, hampir pasti. Untuk mengakomodasi hal ini tim MYCIN menggunakan certainty factor (CF) guna menggambarkan tingkat keyakinan pakar terhadap permasalahan yang sedang dihadapi.')

                );


?>
<?php foreach ($materi as $isi) :?>
<div class="row">
    <div class="col-md-12 ui-sortable">
        <div style="" class="panel panel-inverse">
            <div class="panel-heading">
                <h4 class="panel-title"><?php echo $isi['title'];?></h4>
            </div>
            <div class="panel-body">
                <?php echo nl2br($isi['content']);?>
            </div>
        </div>
    </div>
</div>
<?php endforeach;?>