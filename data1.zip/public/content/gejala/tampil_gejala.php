<h3>ID GEJALA : <?php echo $gejala->kd_gejala;?></h3>
<hr/>
<div class="row">
	<div class="col col-md-12">
	<table class="table table-bordered table-hover table-responsive table-striped">
		<tr>
			<th>TGL INPUT</th>
			<td><?php echo $this->apps->date($gejala->tgl_input);?></td>
		</tr>
		<tr>
			<th>ID GEJALA</th>
			<td><?php echo $gejala->kd_gejala;?></td>	
		</tr>	
		<tr>
			<th>NAMA GEJALA</th>
			<td><?php echo $gejala->nm_gejala;?></td>
		</tr>
		<tr>
			<th>PENYAKIT TERKAIT</th>
			<td>
				<?php
					$query = $this->db->where('kd_gejala',$gejala->kd_gejala)
									  ->get('tb_relasi');
					if ($query->num_rows() > 0) 
					{
						echo "<p>Daftar Penyakit yang terkait dengan Gejala ini :</p>";
						foreach ($query->result() as $penyakit) 
						{
						 	$query = $this->db->where('kd_penyakit', $penyakit->kd_penyakit)
												->get('tb_penyakit');
							if ($query->num_rows() > 0) 
							{
								$no = 1;
								foreach ($query->result() as $items) 
								{
									echo '- ' .$items->nm_penyakit."<br/>";
								}
							}
						}
					}
					else
					{
						echo "belum ada data penyakit yang terhubung dengan gejala ini.";
					}

				?>
			</td>
		</tr>
	</table>
	<a href="<?php echo base_url('index.php/gejala');?>" class="btn btn-success">Kembali</a>
	</div>
</div>