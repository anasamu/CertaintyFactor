<h3>Daftar Gejala</h3>
<hr/>
<table class="table table-responsive table-hover table-bordered table-striped">
	<thead>
		<tr>
			<th>ID GEJALA</th>
			<th>NAMA GEJALA</th>
			<th>INPUT</th>
		</tr>
	</thead>
	<tbody>
		<?php 
		$query = $this->db->get('tb_gejala');
		?>

		<?php foreach ($query->result() as $gejala) :?>
		<tr>
			<td><?php echo $gejala->kd_gejala;?></td>
			<td><?php echo $gejala->nm_gejala;?></td>
			<td>
				<a href="<?php echo base_url('index.php/gejala/tampil/'.$gejala->kd_gejala);?>" class="btn btn-success btn-sm">Tampil</a> 
				<a href="#edit-<?php echo $gejala->kd_gejala;?>" data-toggle="modal" class="btn btn-primary btn-sm">Edit</i></a>
				<a href="#hapus-<?php echo $gejala->kd_gejala;?>" data-toggle="modal" class="btn btn-danger btn-sm">Delete</i></a>
			</td>
		</tr>
		<?php endforeach;?>
	</tbody>
</table>
<a href="#tambah" class="btn btn-success" data-toggle="modal">Tambah Gejala</a>

<div class="modal fade" id="tambah">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
				<h4 class="modal-title">Tambah Gejala</h4>
			</div>
			<form action="<?php echo base_url('index.php/gejala/tambah');?>" method="post">
				<div class="modal-body">
					<div class="form-group">
				      <label for="id">ID Gejala :</label>
				      <input name="id_gejala" value="<?php echo $this->apps->id_table('G00','kd_gejala','tb_gejala');?>" type="text" class="form-control" id="id" readonly="readonly">
				    </div>
				    <div class="form-group">
				        <label for="gejala">Gejala :</label>
				        <textarea name="gejala" class="form-control" id="gejala" rows="4"></textarea>
				    </div>
				</div>
				<div class="modal-footer">
					<a href="#" class="btn btn-sm btn-white" data-dismiss="modal">Close</a>
					<button type="submit" class="btn btn-sm btn-success">Simpan</button>
				</div>
			</form>
		</div>
	</div>
</div>
<?php 
$query = $this->db->get('tb_gejala');
?>

<?php foreach ($query->result() as $gejala) :?>

<div class="modal fade" id="edit-<?php echo $gejala->kd_gejala;?>">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
				<h4 class="modal-title">Edit Gejala</h4>
			</div>
			<form action="<?php echo base_url('index.php/gejala/update');?>" method="post">
				<div class="modal-body">
					<div class="form-group">
				      <label for="id">ID Gejala :</label>
				      <input name="id_gejala" value="<?php echo $gejala->kd_gejala;?>" type="text" class="form-control" id="id" readonly="readonly">
				    </div>
				    <div class="form-group">
				        <label for="gejala">Gejala :</label>
				        <textarea name="gejala" class="form-control" id="gejala" rows="4"><?php echo $gejala->nm_gejala;?></textarea>
				    </div>
				</div>
				<div class="modal-footer">
					<a href="#" class="btn btn-sm btn-white" data-dismiss="modal">Close</a>
					<button type="submit" class="btn btn-sm btn-success">Update</button>
				</div>
			</form>
		</div>
	</div>
</div>

<div class="modal fade" id="hapus-<?php echo $gejala->kd_gejala;?>">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
				<h4 class="modal-title">Hapus Gejala</h4>
			</div>
			<div class="modal-body">
				<p>Apakah anda yakin ingin menghapus ID Gejala : <?php echo $gejala->kd_gejala;?> ?<br/>
				Menghapus Gejala akan mempengaruhi data pengetahuan dan data nilai yang terkait dengan gejala ini.</p>
			</div>
			<div class="modal-footer">
				<a href="#" class="btn btn-sm btn-white" data-dismiss="modal">Close</a>
				<a href="<?php echo base_url('index.php/gejala/hapus/'.$gejala->kd_gejala);?>" class="btn btn-sm btn-danger">Hapus</a>
			</div>
		</div>
	</div>
</div>
<?php endforeach;?>