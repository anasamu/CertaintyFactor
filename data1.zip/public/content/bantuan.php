<div class="row">
	<div class="span12">
	<div class="panel panel-default">
	  <div class="panel-heading"><h3>Bantuan Program <?php echo $this->config->item('judul_aplikasi');?></h3></div>
	  <div class="panel-body">
	  	<ul class="list-group">
		  <li class="list-group-item">Silahkan Buka Alamat Aplikasi : <?php echo base_url();?></li>
		  <li class="list-group-item">Klik Menu <b>"Diagnosa"</b> untuk melakukan diagnosa pasien.</li>
		  <li class="list-group-item">Silahkan isi Biodata diri pasien. dan klik tombol <b>"Diagnosa Pasien"</b>.</li>
		  <li class="list-group-item">Silahkan Centang Gejala-gejala yang dirasakan/dialami oleh pasien.</li>
		  <li class="list-group-item">Silahkan Klik <b>"Proses"</b> untuk mendiagnosa gejala-gejala pasien</li>
		</ul>
	  </div>
	</div>
	</div>
</div>
<br/>
<br/>