<div class="well well-sm">
	<h2><i class="fa fa-user"></i> Profil Pembuat Aplikasi</h2>
	<br/>
	<table class="table table-bordered table-hover table-striped">
		
		<tr>
			<td>NIM</td>
			<td><?php echo strtoupper($this->config->item('nim_mahasiswa'));?></td>
		</tr>
		<tr>
			<td>Nama Mahasiswa</td>
			<td><?php echo strtoupper($this->config->item('nama_mahasiswa'));?></td>
		</tr>
		<tr>
			<td>Fakultas</td>
			<td><?php echo strtoupper($this->config->item('fakultas'));?></td>
		</tr>
		<tr>
			<td>Jurusan</td>
			<td><?php echo strtoupper($this->config->item('jurusan'));?></td>
		</tr>
		<tr>
			<td>Judul Penelitian</td>
			<td><?php echo $this->config->item('judul_skripsi');?></td>
		</tr>
		<tr>
			<td>Metode Penelitian</td>
			<td><?php echo $this->config->item('metode_penelitian');?></td>
		</tr>
		<tr>
			<td>Object Penelitian</td>
			<td><?php echo $this->config->item('object_penelitian');?></td>
		</tr>
	</table>
<strong><p align="center" class="text-center">Penelitian ini dibuat sebagai syarat untuk memperoleh gelar Sarjana (S.Kom) pada Universitas Ichsan Gorontalo Fakultas Ilmu Komputer Program Studi Teknik Informatika.
</p></strong>
</div>
<br/>