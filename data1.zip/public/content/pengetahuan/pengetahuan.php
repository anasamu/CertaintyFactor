<div style="" class="panel panel-inverse" data-sortable-id="form-stuff-1">
    <div class="panel-heading">
        <div class="panel-heading-btn">
            <a href="#" class="btn btn-xs btn-icon btn-circle btn-default" data-click="panel-expand"><i class="fa fa-expand"></i></a>
            <a href="#" class="btn btn-xs btn-icon btn-circle btn-success" data-click="panel-reload"><i class="fa fa-repeat"></i></a>
            <a href="#" class="btn btn-xs btn-icon btn-circle btn-warning" data-click="panel-collapse"><i class="fa fa-minus"></i></a>
        </div>
        <h4 class="panel-title">Data Pengetahuan</h4>
    </div>
	<div class="panel-body">
            <form action="<?php echo base_url('index.php/pengetahuan');?>" method="GET" class="form-horizontal">
            <div class="form-group">
                <label class="col-md-4 control-label">Pilih Data Penyakit : </label>
                <div class="col-md-3">
                    <select name="id" class="form-control">
                        <option value="0">Data Penyakit</option>
                        <?php
                        	$query = $this->db->get('tb_penyakit');

                        	foreach ($query->result() as $items) 
                        	{
                        		echo "<option value='".$items->kd_penyakit."'>".$items->nm_penyakit."</option>";
                        	}
                        ?>
                    </select>
                </div>
                <div>
                	<button type="submit" class="btn btn-success">Proses Penyakit</button>
                </div>
            </div>
            </form>
            <form action="<?php echo base_url('index.php/pengetahuan/update');?>" method="POST">
            <hr/>
            <?php 
            	$id_penyakit	 = $this->input->get('id');
            	$query 			 = $this->db->where('kd_penyakit',$id_penyakit)
            								->get('tb_penyakit');
            	if ($query->num_rows() > 0) 
            	{
            	 	echo "<h3>Penyakit yang dipilih : ".$query->row()->nm_penyakit."</h3>";
            	 	echo "<input type='hidden' name='kd_penyakit' value='".$query->row()->kd_penyakit."'>";
            	}

                if ($this->input->get('redirect')) 
                {
                    echo "<input type='hidden' name='redirect' value='".$this->input->get('redirect')."'>";
                }
            ?>
            <table class="table table-hover table-responsive table-bordered table-striped">
            	<thead>
            		<tr>
            			<th align="center">ID GEJALA</th>
            			<th>NAMA GEJALA</th>
            			<th></th>
            		</tr>
            	</thead>
            	<tbody>
            		<?php if ($id_penyakit):?>
                        
                        <?php
                        $query = $this->db->get("tb_gejala");
                        ?>

                        <?php foreach ($query->result() as $items):?>
                        <tr>
                            <td align="center"><?php echo $items->kd_gejala;?></td>
                            <td><?php echo $items->nm_gejala;?></td>
                            <td>
                                <?php
                                $query = $this->db->where('kd_penyakit',$id_penyakit)
                                                  ->where('kd_gejala',$items->kd_gejala)
                                                  ->get('tb_relasi');
                                if ($query->num_rows() > 0) 
                                {
                                    echo "<input value='".$query->row()->id_relasi."' type='hidden' name='kd_relasi[]'>";
                                    echo "<input checked value='".$items->kd_gejala."' type='checkbox' name='kd_gejala[]' class='form-control' >";
                                }
                                else
                                {
                                    echo "<input value='".$items->kd_gejala."' type='checkbox' name='kd_gejala[]' class='form-control' >";
                                }

                                ?>
                            </td>
                        </tr>
                        <?php endforeach;?>
                    
                    <?php else:?>
                        <tr>
                            <td colspan="3">Data Penyakit belum dipilih.</td>
                        </tr>
                    <?php endif;?>
            	</tbody>
            </table>
            <?php if ($id_penyakit):?>
            <button type="submit" class="btn btn-success pull-right">Simpan Data</button>
            </form>
            <?php endif;?>
    </div>
</div>
