<div class="row">
<div class="col-md-12">
					<ul class="nav nav-tabs">
						<li class="active"><a aria-expanded="true" href="#default-tab-1" data-toggle="tab"><i class="fa fa-dot-circle-o"></i>  Menu Diagnosa</a></li>
						<li class=""><a aria-expanded="false" href="#default-tab-2" data-toggle="tab"><i class="fa fa-dot-circle-o"></i> Daftar Pasien</a></li>
					</ul>
				<div class="tab-content">
						<div class="tab-pane fade active in" id="default-tab-1">
								<h3>Masukan Data Pasien :</h3>
								<hr/>
								<form method="POST" action="<?php echo base_url('index.php/diagnosa/proses');?>" novalidate="" class="form-horizontal" data-parsley-validate="true" name="demo-form">
								<div class="form-group">
									<label class="control-label col-md-4 col-sm-4" for="id">ID PASIEN :</label>
									<div class="col-md-6 col-sm-6">
										<input readonly="readonly" class="form-control" id="id_pasien" name="id" data-parsley-required="true" type="text" value="<?php echo $this->apps->id_table('H00','id_diagnosa','tb_pasien');?>">
									</div>
								</div>
								<div class="form-group">
									<label class="control-label col-md-4 col-sm-4" for="pasien">NAMA PASIEN :</label>
									<div class="col-md-6 col-sm-6">
										<input autofocus="autofocus" class="form-control" id="pasien" name="pasien" placeholder="Nama Pasien" data-parsley-required="true" type="text">
									</div>
								</div>
								<div class="form-group">
									<label class="control-label col-md-4 col-sm-4" for="alamat">ALAMAT PASIEN :</label>
									<div class="col-md-6 col-sm-6">
										<textarea class="form-control" id="alamat" name="alamat" rows="4" data-parsley-range="[20,200]" placeholder="Alamat Pasien"></textarea>
									</div>
								</div>
								<div class="form-group">
									<label class="control-label col-md-4 col-sm-4"></label>
									<div class="col-md-6 col-sm-6">
										<button type="submit" class="btn btn-success">Diagnosa Pasien</button>
									</div>
								</div>
                            </form>
						</div>
						<div class="tab-pane fade" id="default-tab-2">
							<table id="data-table" class="table table-striped table-bordered">
                                <thead>
                                    <tr>
                                        <th>ID PASIEN</th>
                                        <th>NAMA PASIEN</th>
                                        <th>ALAMAT</th>
                                        <th>ACTION</th>
                                    </tr>
                                </thead>
                                <tbody>
                                <?php 
		            			$query = $this->db->get('tb_pasien');
		            			$hasil = $query->result();?>
		            			<?php foreach($hasil as $pasien):?>
                                	<tr>
                                        <td><?php echo $pasien->id_diagnosa;?></td>
                                        <td><?php echo $pasien->nama;?></td>
                                        <td><?php echo nl2br($pasien->alamat);?></td>
                                        <td>
                                        	<a href="<?php echo base_url('index.php/diagnosa/views/'.$pasien->id_diagnosa);?>">views</a> 
			            					<?php if ($this->session->userdata('logged_in') == TRUE):?>
											| 
											<a href="<?php echo base_url('index.php/diagnosa/delete/'.$pasien->id_diagnosa);?>">delete</a>	
					            			
					            			<?php endif;?>
					            		</td>
                                	</tr>
                                <?php endforeach;?>
                                </tbody>
                            </table>
						</div>
					</div>
				</div>
</div>