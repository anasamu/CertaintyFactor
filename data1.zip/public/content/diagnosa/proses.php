
<h3>Silahkan Pilih Gejala Pasien : </h3>
<hr/>

<form action="<?php echo base_url('index.php/diagnosa/hasil');?>" method="POST">
<table id="data-table" class="table table-hover table-bordered table-responsive table-striped">
	<thead>
		<tr>
			<th>ID PASIEN</th>
			<th>NAMA PASIEN</th>
			<th>ALAMAT PASIEN</th>
		</tr>
		<tr>
			<td><?php echo $this->session->userdata('id_pasien');?></td>
			<td><?php echo $this->session->userdata('pasien');?></td>
			<td><?php echo nl2br($this->session->userdata('alamat_pasien'));?></td>
		</tr>
		<tr>
			<td colspan="3"><div align="center"><h4>DAFTAR GEJALA PENYAKIT</h4></div></td>
		</tr>
		<tr>
			<th>ID GEJALA</th>
			<th>Nama Gejala</th>
			<th></th>
		</tr>
	</thead>
	<tbody>
	<?php
	$query = $this->db->get('tb_gejala');
	$hasil = $query->result();
	?>

	<?php foreach ($hasil as $items):?>
	<tr>
		<td><?php echo $items->kd_gejala;?></td>
		<td><?php echo $items->nm_gejala;?></td>
		<td>
			<div align="center"><input class="checkbox" type="checkbox" name="gejala[]" value="<?php echo $items->kd_gejala; ?>"></div>
		</td>
	</tr>
	<?php endforeach;?>
	</tbody>
	<tfoot>
		<tr>
			<td colspan="3" align="right">
				<button type="reset" class="btn btn-primary">Reset</button>
				<button type="submit" class="btn btn-success">Proses</button>
			</td>
		</tr>
	</tfoot>
</table>

</form>