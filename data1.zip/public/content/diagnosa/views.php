<h3>Hasil Diagnosa</h3>
<table class="table table-bordered table-condensed table-hover table-striped">
	<tr>
		<th>TGL DIAGNOSA</th>
		<td><?php echo $this->apps->date($user->date_register);?></td>
	</tr>
	<tr>
		<th>ID PASIEN</th>
		<td><?php echo $user->id_diagnosa;?></td>
	</tr>
	<tr>
		<th>NAMA PASIEN</th>
		<td><?php echo $user->nama;?></td>
	</tr>
	<tr>
		<th>ALAMAT PASIEN</th>
		<td><?php echo nl2br($user->alamat);?></td>
	</tr>
	<tr>
		<th>Penyakit yang diderita Pasien</th>
		<td><?php echo $penyakit->nm_penyakit;?></td>
	</tr>
	<tr>
		<th>Definisi Tentang Penyakit <?php echo $penyakit->nm_penyakit;?></th>
		<td><?php echo nl2br($penyakit->definisi);?></td>
	</tr>
	<tr>
		<th>Penyebab Penyakit <?php echo $penyakit->nm_penyakit;?></th>
		<td><?php echo nl2br($penyakit->penyebab);?></td>
	</tr>
	<tr>
		<th>Solusi Untuk Penyakit <?php echo $penyakit->nm_penyakit;?></th>
		<td><?php echo nl2br($penyakit->solusi);?></td>
	</tr>
</table>
<a href="<?php echo base_url('index.php/diagnosa');?>" class="btn btn-success">Kembali</a>