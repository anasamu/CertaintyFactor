<div class="row">
	<div class="span12">
		<?php echo $html;?>
	</div>	
</div>