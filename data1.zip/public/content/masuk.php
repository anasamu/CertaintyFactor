<div class="row">
	<div class="span12">
		<?php echo $this->session->flashdata('pesan');?>
		<h3>Login Sistem :</h3>
		<hr/>
		<p>
			Silahkan Masukan Username dan Password untuk login ke <?php echo $this->config->item('judul_aplikasi');?>
		</p>
		<form class="form" method="POST" action="<?php echo base_url('index.php/masuk');?>">
			<div class="form-group">
			  <label for="usr">Username:</label>
			  <input name="usr" type="text" class="form-control" id="usr">
			</div>
			<div class="form-group">
			  	<label for="pwd">Password:</label>
			  	<input name="pwd" type="password" class="form-control" id="pwd">
			</div>
			<div class="form-group">
				<button type="reset" class="btn btn-primary">Reset</button>
				<button type="submit" class="btn btn-success">Login</button>
			</div>
		</form>
	</div>
</div>
<br/>
<br/>
<br/>