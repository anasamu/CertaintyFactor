<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Diagnosa extends CI_Controller 
{
	public function index()
	{
		$this->apps->content('diagnosa/diagnosa');
	}

	public function views($id_pasien)
	{
		$user = $this->db->where('id_diagnosa',$id_pasien)
						->get('tb_pasien');
		if ($user->num_rows() > 0) 
		{
			$diagnosa = $this->db->where('id_pasien',$id_pasien)
								->get('tb_diagnosa');
			
				$penyakit = $this->db->where('kd_penyakit',$diagnosa->row()->id_penyakit)
									->get('tb_penyakit');

				$data['user'] 		= $user->row();
				$data['penyakit'] 	= $penyakit->row();
				$this->apps->content('diagnosa/views',$data);
		}
		else
		{
			$this->apps->pesan_error("pasien dengan ID PASIEN $id_pasien tidak ditemukan dalam sistem.");
			redirect(base_url('index.php/diagnosa'));
		}
	}

	public function delete($id_pasien)
	{
		if ($this->session->userdata('logged_in') == TRUE) 
		{
			$this->db->where('id_diagnosa',$id_pasien)
					->delete('tb_pasien');
			$this->db->where('id_pasien',$id_pasien)
						->delete('tb_diagnosa');
			$this->apps->pesan_sukses("pasien dengan ID Pasien : $id_pasien berhasil dihapus.");
			redirect(base_url('index.php/diagnosa'));
		}
		else
		{
			$this->apps->pesan_error("silahkan login untuk mengakses menu ini.");
			redirect(base_url('index.php/diagnosa'));
		}

	}

	public function proses()
	{

		$this->form_validation->set_rules('id', 'Id','trim|required');
		$this->form_validation->set_rules('pasien', 'Pasien','trim|required');
		$this->form_validation->set_rules('alamat', 'Alamat','trim|required');

		if (!$this->form_validation->run())
        {
        	$this->session->set_flashdata('pesan','<div class="alert alert-danger">
												  <strong>Kesalahan!</strong> silahkan isi bidang nama pasien dan alamat pasien untuk di proses.
												</div>');
        	redirect(base_url('index.php/diagnosa'));
        }
        else
        {
        	$userdata_pasien = array('id_pasien' 	=> $this->input->post('id'),
        				  				'pasien' 		=> $this->input->post('pasien'),
			        				  'alamat_pasien' 		=> $this->input->post('alamat')
			      				);
        	$this->session->set_userdata($userdata_pasien);
        	$this->apps->content('diagnosa/proses');
        }
	}

	public function hasil()
	{
		$this->form_validation->set_rules('gejala[]', 'Gejala[]','trim|required');
		if (!$this->form_validation->run())
        {
        	$pasien = array('id_pasien','pasien','alamat_pasien');
				$this->session->unset_userdata($pasien);
        	$this->apps->pesan_error('tidak dapat melakukan diagnosis pada pasien. daftar gejala pasien tidak dicentang. minimal pilih 2 gejala. untuk melakukan proses diagnosis.');
        	redirect(base_url('index.php/diagnosa'));
        }
        else
        {
        	$post_gejala 			= $this->input->post('gejala[]');
			$html 					= '';
			$post 					= '';
			$no 					= 0;



			$html .= '<ul class="nav nav-tabs">
		  <li class="active">
		  	<a data-toggle="tab" href="#utama">Hasil Diagnosa</a>
		  </li>
		  <li>
		  	<a data-toggle="tab" href="#perhitungan">Logika Perhitungan</a>
		  </li>
		</ul>';
			$html .= '<div class="tab-content">
		  <div id="perhitungan" class="tab-pane fade">';
			$html .= "<h3>Rumus Perhitungan : </h3><hr/>";
			$html .= "Kode Gejala yang dipilih : ";
			foreach ($post_gejala as $items) 
			{
				$html .= $items.',';
			}
			$html .= "<hr/>";
			$html .= "<p>Cara Kerja Perhitungan Certainty Factor :</p>";
			$html .= "<ol><li>Mencari Kode Penyakit sesuai dengan kode Gejala yang dipilih.</li>";
			$html .= "<li>Menghitung jumlah gejala dari kode penyakit yang ditemukan.</li>";
			$html .= "<li>Mencari Nilai MB dan MD pada Kode Penyakit dan kode Gejala yang dipilih.</li>";
			$html .= "<li>Jika jumlah gejala yang ditemukan hanya 1 gejala</li>";
			$html .= "<li>tentukan Nilai CF dengan rumus <strong>'CF = MB * MD'</strong></li>";
			$html .= "<li>Jika jumlah gejala yang ditemukan lebih dari 1 gejala</li>";
			$html .= "<li>pada gejala pertama buat variabel MBlama dan MBbaru dan diisi dengan nilai MB dan MD gejala pertama.</li>";
			$html .= "<li>pada gejala berikutnya masukan nilai MB dan MD menjadi MBbaru dan MDbaru kemuadian hitung nilai dari variabel MBsementara dan MDsementara</li>";
			$html .= "<li>MBsementara = MBlama + (MBbaru * (1 - MBlama)) </li>";
			$html .= "<li>MDsementara = MDlama + (MDbaru * (1 - MDlama)) </li>";
			$html .= "<li>Tentukan nilai <strong>'CF = MBsementara + MDsementara'</strong> </li></ol>";
			$html .= "<hr/>";
			empty($daftar_penyakit);
			empty($daftar_cf);
			if ($post_gejala !== '') 
			{
				$query 	= $this->db->select('kd_penyakit')
									->where_in('kd_gejala',$post_gejala)
									->group_by('kd_penyakit')
									->order_by('kd_penyakit')
									->get('tb_relasi');

        		$tb_relasi 				= $query->result();
        		$id_penyakit_terbesar 	= '';
				$nama_penyakit_terbesar = '';
				$c = 0;

				if ($query->num_rows() == 0) 
				{
					$this->apps->pesan_error('tidak dapat melakukan diagnosa pada pasien. daftar penyakit yang ada belum di input dengan gejala yang dipilih.Silahkan cek di menu pengetahuan dengan gejala terkait.');
        			redirect(base_url('index.php/diagnosa'));
				}

				foreach ($tb_relasi as $relasi) 
				{
					$id_penyakit 			= $relasi->kd_penyakit;
					$query 		 			= $this->db->where('kd_penyakit',$id_penyakit)
														->get('tb_penyakit');

					$penyakit 				= $query->row();


					$nama_penyakit 			= $penyakit->nm_penyakit;
					$daftar_penyakit[$c] 	= $relasi->kd_penyakit;
					
					$html .= "<h2>Proses Penyakit : ".$daftar_penyakit[$c].".".$nama_penyakit."</h2><hr/>";
					
					$query = $this->db->where_in('kd_gejala',$post_gejala)
										->where('kd_penyakit',$id_penyakit)
										->get('tb_relasi');

					//$html .= $query.'<br/>';

					$m = $query;
					//mencari jumlah gejala yang ditemukan
					$jml = $m->num_rows($m);
					
					//jika gejalanya 1 langsung ketemu CF nya
					
					$html .= "<p>Jumlah Gejala yang akan diproses : ".$jml."</p>";
					if($jml == 1)
					{
						$h 	= $m->row();
						$mb = $h->mb;
						$md = $h->md;
						$cf = $mb - $md;
						
						$daftar_cf[$c] = $cf;
						//cek apakah penyakit ini adalah penyakit dgn CF terbesar ?
						
						if (($id_penyakit_terbesar == '') || ($cf_terbesar < $cf))
						{
							$cf_terbesar = $cf;
							$id_penyakit_terbesar = $id_penyakit;
							$nama_penyakit_terbesar = $nama_penyakit;
						}

						$html .= "proses 1<br/>------------------------<br/>";
						$html .= "MB = ".$mb."<br/>";
						$html .= "MD = ".$md."<br/>";
						$html .= "<strong>CF = mb - md </strong> // Rumus Perhitungan Certainty Factor menentukan Nilai CF<br/>";
						$html .= $cf .' = '. $mb." - ".$md;
						$html .= "<hr/>";
					}

					//jika gejala lebih dari satu harus diproses semua gejala
					else if ($jml > 1)
					{
						$i = 1;

						foreach ($m->result() as $h) 
						{
							$html .= "<br/>proses ".$i."<br/>------------------------------------<br/>";

							if ($i == 1)
							{
								// $html .= '<p>pada gejala yang pertama masukkan MB dan MD menjadi MBlama dan MDlama</p>';
								$mblama = $h->mb;
								$mdlama = $h->md;
								$html .= "MBlama = ".$mblama."<br/>";
								$html .= "MDlama = ".$mdlama."<br/>";
							}

							else if ($i == 2)
							{
								// $html .= '<p>pada gejala yang nomor dua masukkan MB dan MD menjadi MBbaru dan MB baru kemudian hitung MBsementara dan MDsementara</p>';
								$mbbaru = $h->mb;
								$mdbaru = $h->md;
								$html .= "MBbaru = ".$mbbaru."<br/>";
								$html .= "MDbaru = ".$mdbaru."<br/>";
								
								$mbsementara = $mblama + ($mbbaru * (1 - $mblama));
								$mdsementara = $mdlama + ($mdbaru * (1 - $mdlama));
								
								$html .= "<strong> MBsementara = MBlama + (MBbaru * (1 - MBlama))</strong> // Rumus Perhitungan Certainty Factor untuk menentukan nilai MBsementara<br/>"; 
								$html .= $mbsementara ." = ". $mblama ." +  (".$mbbaru ." * (1 - ".$mblama."))<br/>";
								$html .= "<strong> MDsementara = MDlama + (MDbaru * (1 - MDlama))</strong> // Rumus Perhitungan Certainty Factor untuk menentukan nilai MDsementara<br/>"; 
								$html .= $mdsementara ." = ". $mdlama ." +  (".$mdbaru ." * (1 - ".$mdlama."))<br/>";
								//jika jumlah gejala cuma dua maka CF ketemu
								if ($jml == 2)
								{
									$mb = $mbsementara;
									$md = $mdsementara;
									$cf = $mb - $md;
									$html .= "MB = ".$mb."<br/>";
									$html .= "MD = ".$md."<br/>";
									$html .= "<strong>CF = mb - md </strong> // Rumus Perhitungan Certainty Factor menentukan Nilai CF<br/>";
									$html .= $cf ." = ". $mb." - ".$md."<br/><br/><hr/>";
									$daftar_cf[$c] = $cf;
									//cek apakah penyakit ini adalah penyakit dgn CF terbesar ?
									if (($id_penyakit_terbesar == '') || ($cf_terbesar < $cf))
									{
										$cf_terbesar = $cf;
										$id_penyakit_terbesar = $id_penyakit;
										$nama_penyakit_terbesar = $nama_penyakit;
									}
								}
							}
							//pada gejala yang ke 3 dst proses MBsementara dan MDsementara menjadi MBlama dan MDlama
							//MB dan MD menjadi MBbaru dan MDbaru
							//hitung MBsementara dan MD sementara yg sekarang
							else if ($i >= 3)
							{
								// $html .= '<p>pada gejala yang ke 3 dst.. proses MBsementara dan MDsementara menjadi MBlama dan MDlama<br>MB dan MD menjadi MBbaru dan MDbaru<br>hitung MBsementara dan MDsementara yg sekarang</p>';
								$sebelum = $i -1;
								$mblama = $mbsementara;
								$mdlama = $mdsementara;
								$html .= "MBlama = ".$mblama." // Nilai dari MBsementara pada proses ".$sebelum."<br/>";
								$html .= "MDlama = ".$mdlama." // Nilai dari MDsementara pada proses ".$sebelum."<br/>";
								$mbbaru = $h->mb;
								$mdbaru = $h->md;
								$html .= "MBbaru = ".$mbbaru."<br/>";
								$html .= "MDbaru = ".$mdbaru."<br/>";
								$mbsementara = $mblama + ($mbbaru * (1 - $mblama));
								$mdsementara = $mdlama + ($mdbaru * (1 - $mdlama));
								
								$html .= "<strong> MBsementara = MBlama + (MBbaru * (1 - MBlama))</strong> // Rumus Perhitungan Certainty Factor untuk menentukan nilai MBsementara<br/>"; 
								$html .= $mbsementara ." = ". $mblama ." +  (".$mbbaru ." * (1 - ".$mblama."))<br/>";
								$html .= "<strong> MDsementara = MDlama + (MDbaru * (1 - MDlama))</strong> // Rumus Perhitungan Certainty Factor untuk menentukan nilai MDsementara<br/>"; 
								$html .= $mdsementara ." = ". $mdlama ." +  (".$mdbaru ." * (1 - ".$mdlama."))<br/>";
								//jika ini adalah gejala terakhir berarti CF ketemu
								if ($jml == $i)
								{
									$mb = $mbsementara;
									$md = $mdsementara;
									$cf = $mb - $md;
									$html .= "<br/>";
									$html .= "MB = ".$mb." // hasil dari MBsementara<br/>";
									$html .= "MD = ".$md." // hasil dari MDsementara<br/>";
									$html .= "<strong>CF = mb - md </strong> // Rumus Perhitungan Certainty Factor menentukan Nilai CF<br/><br/>";
									$html .= $cf ." = ". $mb." - ".$md."<br/><br/><hr/>";
									$daftar_cf[$c] = $cf;
									//cek apakah penyakit ini adalah penyakit dgn CF terbesar ?
									if (($id_penyakit_terbesar == '') || ($cf_terbesar < $cf))
									{
										$cf_terbesar = $cf;
										$id_penyakit_terbesar = $id_penyakit;
										$nama_penyakit_terbesar = $nama_penyakit;
									}

									$html .= "<h4>Nilai CF terbesar : ".$cf_terbesar."</h4>";
								}
							}
						$i++;
						
						}
					}
					$c++;
				}
        		
			}

			//urutkan daftar gejala berdasarkan besar CF
			for ($i = 0; $i < count($daftar_penyakit); $i++)
			{
				for ($j = $i + 1; $j < count($daftar_penyakit); $j++)
				{
					if ($daftar_cf[$j] > $daftar_cf[$i])
					{
						$t = $daftar_cf[$i];
						$daftar_cf[$i] = $daftar_cf[$j];
						$daftar_cf[$j] = $t;
						
						$t = $daftar_penyakit[$i];
						$daftar_penyakit[$i] = $daftar_penyakit[$j];
						$daftar_penyakit[$j] = $t;
					}
				}
			}
			$html .= '</div>

		  <div id="utama" class="tab-pane fade in active">';
		$html .= '<div class="row">
			<div class="span6">
				<table class="table table-hover table-bordered table-responsive">
				<tr>
					<th>ID PASIEN</th>
					<td>'.$this->session->userdata('id_pasien').'</td>
				</tr>
				<tr>
					<th>NAMA PASIEN</th>
					<td>'.$this->session->userdata('pasien').'</td>
				</tr>
				<tr>
					<th>ALAMAT</th>
					<td>'.nl2br($this->session->userdata('alamat_pasien')).'</td>
				</tr>
				</table>
			</div>
		</div>';
		 $query = $this->db->get('tb_gejala');
		 $hasil = $query->result();

		 $html .= '<table class="table table-striped table-bordered table-hover">
		 	<tr>
		 	<th colspan="2"><div align=\'center\'>HASIL DIAGNOSA PASIEN</div></th>
		 	</tr>
		 	<tr>
		 		<td><strong>Gejala yang dipilih PASIEN</strong></td>';
		 		$html .= "<td>"; 
				 foreach ($hasil as $items) 
				 {
			 		foreach ($post_gejala as $check) 
					{
						if ($items->kd_gejala == $check) 
						{
							$html .= "<li>".$items->nm_gejala."</li>";
						}
					}
				 }
		 	$html .= '</td></tr>
		 	<tr>
		 		<td><strong>Daftar Penyakit yang terkait dengan Gejala PASIEN</strong></td><td>';
		 	for ($i = 0; $i < count($daftar_penyakit); $i++)
		 	{
		 		$query = $this->db->where('kd_penyakit',$daftar_penyakit[$i])
		 							->get('tb_penyakit');
				$hasil = $query->row();

				$html .= "<li>".$hasil->nm_penyakit."</li>";
			}
				$html .= "</td><tr>";
				$html .= "<tr><td><strong>CF Terbesar</strong></td> <td>".$cf_terbesar."</td></tr>";
				$html .= "<td><strong>Kemungkinan PASIEN terkena penyakit</strong></td>";
				$query = $this->db->where('kd_penyakit',$id_penyakit_terbesar)
									->get('tb_penyakit');
				$hasil = $query->row();

				$html .= "<td>".$hasil->nm_penyakit."</td></tr>";
				$html .= "<tr><td><strong>Definisi Penyakit</strong></td><td>$hasil->definisi</td></tr>";
				$html .= "<td><strong>Penyebab</strong></td><td>$hasil->penyebab</td></tr>";
				$html .= "<tr><td><strong>Solusi</strong></td><td>".nl2br($hasil->solusi)."</td></tr>";
				$html .= "</table>";
				$html .= "<a class='btn btn-success pull-right' href='".base_url('index.php/diagnosa')."'>Diagnosa Ulang</a>";
				$html .= "<br/><br/><br/>";
				$html .= '</table>';

		$cek = $this->db->select('id_diagnosa')
						->where('id_diagnosa',$this->session->userdata('id_pasien'))
						->get('tb_pasien');
		
		if ($cek->num_rows() == 0) 
		{
			$pasien = array('id_diagnosa' 	=> $this->session->userdata('id_pasien'),
							'nama' 			=> $this->session->userdata('pasien'),
							'alamat' 		=> $this->session->userdata('alamat_pasien'),
							'date_register' => date('Y-m-d h:m:s')
					);

			$this->db->insert('tb_pasien',$pasien);

			$id 	= $this->apps->id_table('H00','id_diagnosa','tb_pasien');
			
			$data_pasien 	= array('id_diagnosa' 	=> $id,
									'id_pasien' 	=> $this->session->userdata('id_pasien'),
									'id_penyakit' 	=> $id_penyakit_terbesar
								);
			$this->db->insert('tb_diagnosa',$data);

		}

			$data['html'] = $html;
			$this->apps->content('diagnosa/hasil',$data);
        }
	}
}
