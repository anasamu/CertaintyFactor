<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Nilai extends CI_Controller 
{
	public function __construct()
	{
		parent::__construct();
		if ($this->session->userdata('logged_in') == FALSE) 
		{
			$this->apps->pesan_error('Silahkan Login untuk mengakses menu Gejala');
			redirect();
		}
	}

	public function index()
	{
		$this->apps->content('nilai/nilai');
	}

	public function update()
	{
		$kd_penyakit 	= $this->input->post('kd_penyakit');
		$kd_gejala 		= $this->input->post('kd_gejala');
		$mb 			= $this->input->post('nilai_mb');
		$md 			= $this->input->post('nilai_md');
		
		$jum = count($kd_gejala);	

		if($jum==0)
    	{
			redirect(base_url('index.php/nilai?id='.$kd_penyakit));
		}
    	else
    	{
			for($i = 0; $i < $jum; ++$i)
      		{
				$qryr = $this->db->query("SELECT * FROM tb_relasi WHERE kd_penyakit='$kd_penyakit' AND kd_gejala='$kd_gejala[$i]'");
				$cocok = $qryr->num_rows();
				if($cocok==1)
        		{
					$this->db->query("UPDATE tb_relasi SET mb='$mb[$i]', md='$md[$i]' where kd_penyakit='$kd_penyakit' AND kd_gejala='$kd_gejala[$i]'");
				}
			}
			$this->apps->pesan_sukses('Data Nilai berhasil disimpan.');
			redirect(base_url('index.php/nilai?id='.$kd_penyakit));
		}
	}
}