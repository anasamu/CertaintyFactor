<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Gejala extends CI_Controller 
{
	public function __construct()
	{
		parent::__construct();
		if ($this->session->userdata('logged_in') == FALSE) 
		{
			$this->apps->pesan_error('Silahkan Login untuk mengakses menu Gejala');
			redirect();
		}
	}

	public function index()
	{
		$this->apps->content('gejala/gejala');
	}

	public function tampil($id_gejala = null)
	{
		$cek = $this->db->where('kd_gejala',$id_gejala)
						->get('tb_gejala');
		if ($cek->num_rows() > 0) 
		{
			$data['gejala'] = $cek->row();
			$this->apps->content('gejala/tampil_gejala',$data);
		}
		else
		{
			$this->apps->pesan_error("ID Gejala : <strong>".$id_gejala."</strong> tidak ditemukan.");
			redirect(base_url('index.php/gejala'));
		}
	}

	public function update()
	{
		$this->form_validation->set_rules('id_gejala', 'Id_gejala','trim|required');
		$this->form_validation->set_rules('gejala', 'Gejala','trim|required');

		if (!$this->form_validation->run())
        {
			$this->apps->pesan_error('data gejala yang di input tidak benar.');
			redirect(base_url('index.php/gejala'));
		}
		else
		{
			$data_gejala = array('kd_gejala' => $this->input->post('id_gejala'),
								'nm_gejala' => $this->input->post('gejala')
							);
			$this->db->where('kd_gejala',$this->input->post('id_gejala'))
					->update('tb_gejala',$data_gejala);

			$this->apps->pesan_sukses('ID gejala : '.$this->input->post('id_gejala').' berhasil update.');
			redirect(base_url('index.php/gejala'));
		}
	}

	public function tambah()
	{
		$this->form_validation->set_rules('id_gejala', 'Id_gejala','trim|required');
		$this->form_validation->set_rules('gejala', 'Gejala','trim|required');

		if (!$this->form_validation->run())
        {
			$this->apps->pesan_error('data gejala yang di input tidak benar.');
			redirect(base_url('index.php/gejala'));
		}
		else
		{
			$data_gejala = array('tgl_input' => date('Y-m-d h:m:s'),
								'kd_gejala' => $this->input->post('id_gejala'),
								'nm_gejala' => $this->input->post('gejala')
							);
			$this->db->insert('tb_gejala',$data_gejala);
			$this->apps->pesan_sukses('ID gejala : '.$this->input->post('id_gejala').' berhasil ditambahkan.');
			redirect(base_url('index.php/gejala'));
		}
	}

	public function hapus($id_gejala = null)
	{
		$this->db->where('kd_gejala',$id_gejala)
								->delete('tb_relasi');

		$this->db->where('kd_gejala',$id_gejala)
				->delete('tb_gejala');
		$this->apps->pesan_sukses("Data Gejala dengan ID Gejala : <strong>".$id_gejala."</strong> berhasil dihapus");
			redirect(base_url('index.php/gejala'));
	}
}