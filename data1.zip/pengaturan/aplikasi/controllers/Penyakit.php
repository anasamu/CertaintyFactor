<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Penyakit extends CI_Controller 
{
	public function __construct()
	{
		parent::__construct();
		if ($this->session->userdata('logged_in') == FALSE) 
		{
			$this->apps->pesan_error('Silahkan Login untuk mengakses menu penyakit');
			redirect();
		}
	}

	public function index()
	{
		$this->apps->content('penyakit/penyakit');
	}

	public function tambah()
	{
		$this->form_validation->set_rules('id_penyakit', 'Id_penyakit','trim|required');
		$this->form_validation->set_rules('nama_penyakit', 'Nama_penyakit','trim|required');
		$this->form_validation->set_rules('definisi_penyakit', 'Definisi_penyakit','trim|required');
		$this->form_validation->set_rules('penyebab_penyakit', 'Penyebab_penyakit','trim|required');
		$this->form_validation->set_rules('solusi_penyakit', 'Solusi_penyakit','trim|required');
		
		if (!$this->form_validation->run())
        {
			$this->apps->content('penyakit/tambah_penyakit');
		}
		else
		{
			$data_penyakit = array(
									'tgl_input' => date('Y-m-d h:m:s'),
									'kd_penyakit' => $this->input->post('id_penyakit'),
									'nm_penyakit' => $this->input->post('nama_penyakit'),
									'definisi' => $this->input->post('definisi_penyakit'),
									'penyebab' => $this->input->post('penyebab_penyakit'),
									'solusi' => $this->input->post('solusi_penyakit')
								);
			$this->db->insert('tb_penyakit',$data_penyakit);
			$this->apps->pesan_sukses("Data penyakit dengan ID Penyakit : <strong>".$this->input->post('id_penyakit')."</strong> berhasil ditambahkan");
			redirect(base_url('index.php/penyakit'));
		}
	}

	public function tampil($id_penyakit = null)
	{
		$cek = $this->db->where('kd_penyakit',$id_penyakit)
						->get('tb_penyakit');
		if ($cek->num_rows() > 0) 
		{
			$data['penyakit'] = $cek->row();
			$this->apps->content('penyakit/tampil_penyakit',$data);
		}
		else
		{
			$this->apps->pesan_error("ID Penyakit : <strong>".$id_penyakit."</strong> tidak ditemukan.");
			redirect(base_url('index.php/penyakit'));
		}
	}

	public function edit($id_penyakit = null)
	{
		$this->form_validation->set_rules('id_penyakit', 'Id_penyakit','trim|required');
		$this->form_validation->set_rules('nama_penyakit', 'Nama_penyakit','trim|required');
		$this->form_validation->set_rules('definisi_penyakit', 'Definisi_penyakit','trim|required');
		$this->form_validation->set_rules('penyebab_penyakit', 'Penyebab_penyakit','trim|required');
		$this->form_validation->set_rules('solusi_penyakit', 'Solusi_penyakit','trim|required');
		if (!$this->form_validation->run())
        {
			$query = $this->db->where('kd_penyakit',$id_penyakit)
								->get('tb_penyakit');
			if ($query->num_rows() > 0) 
			{
				$data['penyakit'] = $query->row();
				$this->apps->content('penyakit/edit_penyakit',$data);
			}
			else
			{
				$this->apps->pesan_error("ID Penyakit : <strong>".$id_penyakit."</strong> tidak ditemukan.");
				redirect(base_url('index.php/penyakit'));
			}
		}
		else
		{
			$data_penyakit = array('kd_penyakit' => $this->input->post('id_penyakit'),
									'nm_penyakit' => $this->input->post('nama_penyakit'),
									'definisi' => $this->input->post('definisi_penyakit'),
									'penyebab' => $this->input->post('penyebab_penyakit'),
									'solusi' => $this->input->post('solusi_penyakit')
								);
			$this->db->where('kd_penyakit',$this->input->post('id_penyakit'))
					 ->update('tb_penyakit',$data_penyakit);
			$this->apps->pesan_sukses("Data penyakit dengan ID Penyakit : <strong>".$this->input->post('id_penyakit')."</strong> berhasil di ubah.");
			redirect(base_url('index.php/penyakit'));
		}
	}

	public function hapus($id_penyakit = null)
	{
		$this->db->where('kd_penyakit',$id_penyakit)
				->delete('tb_relasi');
		$this->db->where('kd_penyakit',$id_penyakit)
				->delete('tb_penyakit');
		$this->apps->pesan_sukses("Data penyakit dengan ID Penyakit : <strong>".$id_penyakit."</strong> berhasil dihapus");
			redirect(base_url('index.php/penyakit'));
	}
}
