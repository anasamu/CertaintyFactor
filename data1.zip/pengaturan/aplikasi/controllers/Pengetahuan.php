<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Pengetahuan extends CI_Controller 
{

	public function __construct()
	{
		parent::__construct();
		if ($this->session->userdata('logged_in') == FALSE) 
		{
			$this->apps->pesan_error('Silahkan Login untuk mengakses menu Pengetahuan');
			redirect();
		}
	}

	public function index()
	{
		$this->apps->content('pengetahuan/pengetahuan');
	}

	public function update()
	{
		$id_penyakit 	= $this->input->post('kd_penyakit');
		$id_gejala 		= $this->input->post('kd_gejala[]');

		if ($this->input->post('redirect')) 
		{
			$redirect = TRUE;
		}
		else
		{
			$redirect = FALSE;
		}

		$penyakit 		= $this->db->where('kd_penyakit',$id_penyakit)
							->get('tb_relasi');
		$jum = count($id_gejala);
		if($jum == 0)
		{
			$id_relasi 	= $this->input->post('kd_relasi[]');
			$jumlah 	= count($id_relasi);
			
			for ($i=0; $i < $jumlah; ++$i) 
			{ 
				$this->db->where('id_relasi',$id_relasi[$i])
							->delete('tb_relasi');
			}
			$this->apps->pesan_sukses('data Pengetahuan berhasil diubah');
			redirect(base_url('index.php/pengetahuan?id='.$id_penyakit));
		}
		else
		{
			$query = $this->db->query("SELECT * FROM tb_relasi WHERE kd_penyakit='$id_penyakit'");
			
			foreach ($query->result() as $datapil) 
			{
				for($i = 0; $i < $jum; ++$i){
					
					if($datapil->kd_gejala !== $id_gejala[$i])
					{
						$this->db->query("DELETE FROM tb_relasi WHERE kd_penyakit='$id_penyakit' AND NOT kd_gejala IN('$id_gejala[$i]')");
					}
				}
			}

			for($i = 0; $i < $jum; ++$i)
			{
				$query = $this->db->query("SELECT * FROM tb_relasi WHERE kd_penyakit='$id_penyakit' AND kd_gejala='$id_gejala[$i]'");

				if($query->num_rows() == 0)
				{
					$data = array('id_relasi' => $this->apps->id_table('R00','id_relasi','tb_relasi'),
									'kd_penyakit' => $id_penyakit,
									'kd_gejala' => $id_gejala[$i]
								);
					
					$this->db->insert('tb_relasi',$data);
					$this->apps->pesan_sukses('data Pengetahuan berhasil ditambahkan');
				}
				else
				{
					$data = array('kd_penyakit' => $id_penyakit,
									'kd_gejala' => $id_gejala[$i]
								);
					$this->db->where('kd_penyakit',$id_penyakit)
							->where('kd_gejala',$id_gejala[$i])
							->update('tb_relasi',$data);
					$this->apps->pesan_sukses('data Pengetahuan berhasil diubah');
				}
			}

			if ($redirect == TRUE) 
			{
				$this->apps->pesan_sukses('data Pengetahuan berhasil tambahkan. silahkan input nilai penyakit');
				redirect(base_url('index.php/'.$this->input->post('redirect').'?id='.$id_penyakit));
			}
			else
			{
				redirect(base_url('index.php/pengetahuan?id='.$id_penyakit));
			}
		}

	}
}