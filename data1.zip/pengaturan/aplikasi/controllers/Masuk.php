<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Masuk extends CI_Controller 
{
	public function index()
	{
		$this->form_validation->set_rules('usr', 'Usr','trim|required');
		$this->form_validation->set_rules('pwd', 'Pwd','trim|required');
		
		if (!$this->form_validation->run())
        {
			$this->apps->pesan_error('Username atau password tidak boleh kosong.');
			redirect();
		}
		else
		{
			$user 	= $this->input->post('usr');
			$pwd 	= $this->input->post('pwd');

			$query = $this->db->where('user_tht',$user)
					 			->where('passw_tht',md5($pwd))
					 			->get('tb_user');
			if ($query->num_rows() > 0) 
			{
				$userdata = array('logged_in' 	=> TRUE,
								  'nama_user'  	=> $query->row()->nm_lengkap,
								  'username' 	=> $query->row()->user_tht,
								  );
				
				$this->session->set_userdata($userdata);
				$this->apps->pesan_sukses('Selamat login dengan nama user <strong>'.$query->row()->nm_lengkap.'</strong> berhasil.');
				redirect(base_url('index.php/beranda'));
			}
			else
			{
				$this->apps->pesan_error('Username atau password salah.');
				redirect();
			}
		}
	}
}
