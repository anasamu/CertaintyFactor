<?php defined('BASEPATH') OR exit('No direct script access allowed');


$config['judul_aplikasi'] 		= 'Sistem Pakar Diagnosa Penyakit Stroke';
$config['deskripsi_aplikasi'] 	= 'Metode Certainty Factor Puskesmas Motolohu Randangan';


$config['nim_mahasiswa'] 		= 'T3113364';
$config['nama_mahasiswa']		= 'Sumarni Yunus';
$config['fakultas'] 			= 'Ilmu Komputer';
$config['jurusan'] 				= 'Informatika';
$config['judul_skripsi'] 		= 'Sistem Pakar Diagnosa Awal Penyakit Stroke Menggunakan Metode Certanty Factor Pada Puskesmas Motolohu Randangan';

$config['tempat_penelitian'] 	= 'Puskesmas Motoluhu Randangan';
$config['metode_penelitian'] 	= 'Metode Certanty Factor';
$config['object_penelitian'] 	= 'Penyakit Stroke';
