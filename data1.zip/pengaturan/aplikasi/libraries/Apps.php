<?php defined('BASEPATH') OR exit('No direct script access allowed');

Class Apps
{

	public function __get($var)
	{
		return get_instance()->$var;
	}

	public function __construct()
	{
		$this->load->library(array('form_validation'));
		$this->load->helper(array('url','form'));
		$this->load->config('konfigurasi');
	}

	public function content($content,$data = false)
	{
		$data['content'] = $this->load->view("content/$content",$data, TRUE);
		$this->load->view('template/index',$data);
	}

	public function profile()
	{

		if ($this->uri->segment(1) == profile) 
		{
			echo $this->encrypt->decode(ABOUT_ME,PROTECT_KEY);
		}
		else
		{
			$this->content('profil');
		}
	}

	public function id_table($kode_id,$index,$table)
	{
		$query 		= $this->db->select($index)
								->get($table);
		$id 		= $query->num_rows();
		
		for ($i=1; $i <= $id+1; $i++) 
		{
			$kodeid 	= $kode_id.$i;
			$search 	= $this->db->where($index,$kodeid)
									->get($table);

			if ($search->num_rows() > 0) 
			{
				continue;
			}
			else
			{
				return $kodeid;
				break;
			}
		}
		return $kodeid;
	}

	protected function about()
	{
		echo $this->encrypt->encode(ABOUT_ME,PROTECT_KEY);
	}


	public function pesan_error($pesan)
	{
		return $this->session->set_flashdata('pesan','<div class="alert alert-danger">
												  <strong><i class="fa fa-exclamation-circle"></i> Kesalahan!</strong> '.$pesan.'
												</div>');
	}

	public function pesan_sukses($pesan)
	{
		return $this->session->set_flashdata('pesan','<div class="alert alert-success">
												  <strong><i class="fa fa-check-circle"></i> Informasi!</strong> '.$pesan.'
												</div>');
	}

	public function date($date)
	{
		$tanggal = date('Y-m-d', strtotime($date));
		$hari = array ( 1 =>    'Senin',
								'Selasa',
								'Rabu',
								'Kamis',
								'Jumat',
								'Sabtu',
								'Minggu'
							);
				
		$bulan = array (1 =>   'Januari',
								'Februari',
								'Maret',
								'April',
								'Mei',
								'Juni',
								'Juli',
								'Agustus',
								'September',
								'Oktober',
								'November',
								'Desember'
							);

		$split 	  = explode('-', $tanggal);

		$tgl_indo = $split[2] . ' ' . $bulan[ (int)$split[1] ] . ' ' . $split[0];
		
		$num = date('N', strtotime($tanggal));

		return $hari[$num] . ', ' . $tgl_indo;
	}

}